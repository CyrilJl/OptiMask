# -*- coding: utf-8 -*-

# author : Cyril Joly


from ._optimask import OptiMask

__all__ = ['OptiMask']
